package lec250430_circle;

public class Ball extends Circletype {
    public Ball (double rad) {
        this.rad = rad;
    }

	public double getArea() {
		return 4 * PI * rad * rad;
	}
}
