package lec250430_circle;

public class Circle extends Circletype {

	public static final double PI = 3.14;  
	protected double rad;
	
	public Circle(double rad) {
		this.rad = rad;
	}
	
	public double getRad() {
		return rad;
	}
	
	public void setRad(double rad) {
		this.rad = rad;
	}
	
	public double getArea() {
		return PI * rad * rad;
	}

}
