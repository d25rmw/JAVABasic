package lec250430_circle;

public abstract class Circletype {
    
	public static final double PI = 3.14;  
	protected double rad;
	
	public double getRad() {
		return rad;
	}
	
	public void setRad(double rad) {
		this.rad = rad;
	}

    abstract double getArea();
}
