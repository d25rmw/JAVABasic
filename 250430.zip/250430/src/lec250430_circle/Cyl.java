package lec250430_circle;

public class Cyl extends Circletype {
    protected double hgh;
    
    public Cyl(double rad, double hgh) {
        this.rad = rad;
        this.hgh = hgh;
    }
    
    public double getHgh() {
        return hgh;
    }

    public void setHgh(double hgh) {
        this.hgh = hgh;
    }

    @Override
    public double getArea() {
        return 2 * PI * rad * (rad + hgh);
    }

}

