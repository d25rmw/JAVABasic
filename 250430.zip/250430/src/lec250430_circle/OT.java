package lec250430_circle;

public class OT {
    public static void main(String[] args) {
        Circletype ct;
        
        ct = new Circle(5.0);

        System.out.println(">>> 원 : ");
        System.out.println("반지름 : " + ct.getRad());
        System.out.println("면적 : " + ct.getArea());

        Ball ball = new Ball(5.0);
        System.out.println("\n>>> 공 : ");
        System.out.println("반지름 : " + ball.getRad());
        System.out.println("면적 : " + ball.getArea());


        Cyl cyl = new Cyl(5.0, 7.0);
        System.out.println("\n>>> 원기둥 : ");
        System.out.println("높이 : " + ((Cyl)ct).getHgh());
        System.out.println("면적 : " + ct.getArea());
    }
}
