package lec250430_count;

public interface countable {
    void count();
    
}
