package lec250430_count;

public class counttest {
    public static void main(String[] args) {
        countable[] cl = {
            new bird("참새", 5),
            new bird("매", 2),
            new tree("사과나무", 5),
            new tree("포도나무", 3)};

    for (countable cc : cl)
            cc.count();

    for (countable cc : cl) {
        if (cc instanceof bird) {
            ((bird)cc).fly();
        } else {
            ((tree)cc).ripen();
        }
    }
    }
}
