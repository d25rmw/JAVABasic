package lec250430_dao;

public class daoex {
    public static void dbword(dataaccessobject dao) {
        dao.select();
        dao.insert();
        dao.update();
        dao.delete();
    }

    public static void main(String[] args) {
        dbword(new oracledao());
        dbword(new mysqldao());
    }
}
