package lec250430_dao;

public interface dataaccessobject {
    void select();
    void insert();
    void update();
    void delete();
    
}
