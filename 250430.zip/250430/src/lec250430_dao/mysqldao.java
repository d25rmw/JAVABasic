package lec250430_dao;

public class mysqldao implements dataaccessobject {

    @Override
    public void select() {
        System.out.println("select to mysql DB");
    }

    @Override
    public void insert() {
        System.out.println("insert to mysql DB");
    }

    @Override
    public void update() {
        System.out.println("update to mysql DB");
    }

    @Override
    public void delete() {
        System.out.println("delete to mysql DB");
    }
    
}
