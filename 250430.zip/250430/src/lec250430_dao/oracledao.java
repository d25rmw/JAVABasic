package lec250430_dao;

public class oracledao implements dataaccessobject {

    @Override
    public void select() {
        System.out.println("select to DB");
    }

    @Override
    public void insert() {
        System.out.println("insert to DB");
    }

    @Override
    public void update() {
        System.out.println("update to DB");
    }

    @Override
    public void delete() {
        System.out.println("delete to DB");
    }
    
}
