package lec250430_sound;

public class cat implements soundable {
    
    @Override
    public String sound() {
        return "Meow";
    }
}
