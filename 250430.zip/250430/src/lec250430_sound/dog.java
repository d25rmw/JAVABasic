package lec250430_sound;

public class dog implements soundable {
    
    @Override
    public String sound() {
        return "Bark";
    }
}
