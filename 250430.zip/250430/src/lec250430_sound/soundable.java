package lec250430_sound;

public interface soundable {
    String sound();
}
