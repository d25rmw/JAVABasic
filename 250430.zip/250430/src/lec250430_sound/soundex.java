package lec250430_sound;

public class soundex {
    public static void main(String[] args) {
        printsound(new cat());
        printsound(new dog());
    }

    public static void printsound(soundable soundable) {
        System.out.println(soundable.sound());
    }
}
