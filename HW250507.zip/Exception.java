package Exception;

public class Exception {
    public static void main(String[] args) {
        Exception exc = new Exception();
            exc.arithmeticEx();
            exc.indexEx();
            //exc.nullpointerEx();
            exc.numforREx();
    
    }

    public void arithmeticEx() {
        try {
            int a = 10, b = 0;
            int c = a / b;
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }

    public void indexEx() {
        try {
            int[] array = {0, 1, 2};
            System.out.println(array[3]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        }
    }


    public void numforREx() {
        try {
            String str = "123AB";
            int num = Integer.parseInt(str);
            
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
        }
    }
}
