package Exception;

public class Multicatchtest {
    public static void main(String[] args) {
        System.out.println("== Program start ==");

        String[] arr = {"100", "1OO"};

        for (int i = 0; i <= arr.length; i++) {
            try {
                int vl = Integer.parseInt(arr[i]);
                System.out.println("arr[" + i + "]" + vl);
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                System.out.println(e.getMessage());
            } 

            }

            System.out.println("== Program off ==");
        }
}
