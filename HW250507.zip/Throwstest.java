package Exception;

public class Throwstest {
    public static void main(String[] args) throws ClassNotFoundException {
        /* try {
            method1();
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } */
        System.out.println("== Program off ==");
    }

    static void method1() throws ClassNotFoundException {
        method2();
    }

    static void method2() throws ClassNotFoundException {
        Class.forName("java.lang.String2");
    }
}
