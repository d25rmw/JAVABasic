package Exception;

public class Trycatchtest {
    public static void main(String[] args) {
        System.out.println("== Program start ==");
        arithmeticEx();
        System.out.println("== Program off ==");
    }

    public static void arithmeticEx() {
        int a = 10, b = 0;
        
        try {
            int c = a / b;
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }
}
